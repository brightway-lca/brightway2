#!/opt/local/bin/bash
source $HOME/bw2-python/bin/activate bw2 && ipython
